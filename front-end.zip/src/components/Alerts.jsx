import React from 'react'
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Alerts = () => {
  return (
    <div>Alerts</div>
  )
}

export default Alerts